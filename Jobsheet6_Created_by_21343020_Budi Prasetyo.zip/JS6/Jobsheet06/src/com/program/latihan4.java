package com.program;
// Created by 21343020_Budi Prasetyo
public class latihan4 {
    public static void main(String[] args) {
        int grade = 90;

        switch(grade){
            case 100:
                System.out.println("Exellen");
                break;

            case 90:
                System.out.println("Good job");
                break;
        
            case 80:
                System.out.println("Study harder");
                break;   
                    
        default:
                System.out.println("Sorry, you failed.");
        }
    }
}
